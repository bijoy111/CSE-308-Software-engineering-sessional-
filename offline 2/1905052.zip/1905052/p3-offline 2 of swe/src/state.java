public interface state
{

}
