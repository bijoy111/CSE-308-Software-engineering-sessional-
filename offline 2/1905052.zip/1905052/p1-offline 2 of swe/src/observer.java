public abstract class observer
{
    protected subject sub;
    public abstract void update(int s);
    public abstract int get_prevState();
    public abstract int get_currState();
}
