import java.util.ArrayList;

public class Company
{
    private String name;
    private ArrayList<Manager> managers = new ArrayList<>();

    public Company(String name)
    {
        this.name = name;
    }

    public void addManager(Manager manager)
    {
        managers.add(manager);
    }

    public void removeManager(Manager manager)
    {
        managers.remove(manager);
    }

    public ArrayList<Manager> getManagers()
    {
        return managers;
    }

    public void hierarchy()
    {
        System.out.println("    - " + name);
        for (Manager manager : managers)
        {
            System.out.println("        - " + manager.get_name() + " (" + manager.get_Projectname() + ")");
            for (Developer developer : manager.getDevelopers())
            {
                System.out.println("            - " + developer.get_name());
            }
        }
    }
    public String get_name()
    {
        return name;
    }
}
