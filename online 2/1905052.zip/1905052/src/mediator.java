public interface mediator
{
    public void showMsg(String msg);
}
