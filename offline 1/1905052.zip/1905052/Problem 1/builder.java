public interface builder
{
    void add_base_components();
    void add_processor();
    void add_cooler();
    void add_dvd_drive();
    void add_8GB_DDR4_RAM_2666MHZ();
    void add_8GB_DDR4_RAM_3200MHZ();
    void add_2GB_graphics_card();
    void add_4GB_graphics_card();
    product get_pc();
}
