public class controller
{
    private state s;
    public controller()
    {
        s=null;
    }
    public void set_state(state st)
    {
        s=st;
    }
    public state get_state()
    {
        return s;
    }
}
