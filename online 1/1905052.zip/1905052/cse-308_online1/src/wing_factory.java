public class wing_factory extends abstract_factory
{
    private Wing obj=new Wing();
    @Override
    Engine getEngine(String tmp) {
        return null;
    }

    public Wing getWing(String tmp)
    {
        if(tmp==null)
        {
            return null;
        }
        else if(tmp.equalsIgnoreCase("Boeing"))
        {
            obj.set_wing("Boeing");
        }
        else if(tmp.equalsIgnoreCase("AirBus"))
        {
            obj.set_wing("AirBus");
        }
        else if(tmp.equalsIgnoreCase("Safram"))
        {
            obj.set_wing("Safram");
        }
        return null;
    }
}
