import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;
public class reg_user
{
    public static void main(String[] args) throws IOException
    {
        System.out.println("Client started..");
        Socket socket = new Socket("127.0.0.1", 22222);
        System.out.println("Client Connected..");

        ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());

            Scanner sc = new Scanner(System.in);
        System.out.println("Are you a regular user or premium user?");
        System.out.println("If you are a regular user then type regular user");
        System.out.println("Or if you are a premium user then type premium user");
            String message = sc.nextLine();



            //sent to server...
            oos.writeObject(message);

            try {
                while(true) {
                    //receive from server..
                    Object fromServer = ois.readObject();
                    int prev=(int) fromServer;
                    fromServer=ois.readObject();
                    int curr=(int) fromServer;
                    if(prev==0&&curr==1)
                    {
                        System.out.println("The server of ABC company is previously on operational state");
                        System.out.println("The server of ABC company is currently on partially down state");
                        System.out.println("Select a option by typing 1 or 2");
                        System.out.println("1.Do you want to continue using the limited functionality");
                        System.out.println("2.Do you want to pay $20 per hour to enjoy the full functionality taking service from DEF company");
                        int tmp1=sc.nextInt();
                        if(tmp1==1)
                        {
                            System.out.println("Thanks for choosing 1");
                            oos.writeObject(tmp1);
                        }
                        else if(tmp1==2)
                        {
                            System.out.println("Thanks for choosing 2");
                            oos.writeObject(tmp1);
                        }
                    }
                    else if(prev==0&&curr==2)
                    {
                        System.out.println("The server of ABC company is previously on operational state");
                        System.out.println("The server of ABC company is currently on fully down state");
                        System.out.println("Select a option by typing yes or no");
                        System.out.println("Do you want to pay $20 per hour to take service from DEF company");
                        String tmp1=sc.nextLine();
                        if(tmp1.equalsIgnoreCase("yes"))
                        {
                            System.out.println("Thanks for typing yes");
                            oos.writeObject("yes");
                        }
                        else if(tmp1.equalsIgnoreCase("no"))
                        {
                            System.out.println("Thanks for typing no");
                            oos.writeObject("no");
                        }
                    }
                    else if(prev==1&&curr==0)
                    {
                        System.out.println("The server of ABC company is previously on partially down state");
                        System.out.println("The server of ABC company is currently on operational state");
                        System.out.println("Your total bill is: X taka");

                    }
                    else if(prev==1&&curr==2)
                    {
                        System.out.println("The server of ABC company is previously on partially down state");
                        System.out.println("The server of ABC company is currently on fully down state");
                    }
                    else if(prev==2&&curr==0)
                    {
                        System.out.println("The server of ABC company is previously on fully down state");
                        System.out.println("The server of ABC company is currently on operational state");
                        System.out.println("Your total bill is: X taka");
                    }
                    else if(prev==2&&curr==1)
                    {
                        System.out.println("The server of ABC company is previously on fully down state");
                        System.out.println("The server of ABC company is currently on partially down state");
                    }
                    //System.out.println("From Server: " + (String) fromServer);
                }

            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }


        socket.close();

    }
}
