import java.util.*;

public class customer
{
    public static void main(String[] args)
    {
        System.out.println("Design pattern is Builder Pattern");
        Scanner input= new Scanner(System.in);
        while(true)
        {
            System.out.println("Press o to open an order or press S to exit from this page");
            String tmp1 = input.nextLine();
            while(true)
            {
                if(tmp1.equalsIgnoreCase("s"))
                {
                    break;
                }
                if(tmp1.equalsIgnoreCase("o"))
                {
                    break;
                }
                System.out.println("Error!");
                System.out.println("Press o to open an order or press S to exit from this page");
                tmp1 = input.nextLine();
            }
            if(tmp1.equalsIgnoreCase("s"))
            {
                break;
            }

            System.out.println("List of available Pc in our shop are:");
            System.out.println("1.Gaming PC");
            System.out.println("2.Regular PC with Core i5");
            System.out.println("3.Regular PC with Core i7");
            System.out.println("4.Regular PC with Core i9");
            System.out.println("Press the number between 1-4 according to your prerference");
            String a = input.nextLine();
            while(true)
            {
                if(a.equalsIgnoreCase("o"))
                {
                    System.out.println("Error!");
                    System.out.println("Please complete the current order and to complete it please Press the number between 1-4 according to your prerference");
                }
                else if(a.equalsIgnoreCase("1")||a.equalsIgnoreCase("2")||a.equalsIgnoreCase("3")||a.equalsIgnoreCase("4"))
                {
                    break;
                }
                else
                {
                    System.out.println("Error!");
                    System.out.println("List of available Pc in our shop are:");
                    System.out.println("1.Gaming PC");
                    System.out.println("2.Regular PC with Core i5");
                    System.out.println("3.Regular PC with Core i7");
                    System.out.println("4.Regular PC with Core i9");
                    System.out.println("Press the number between 1-4 according to your prerference");
                }
                a = input.nextLine();
            }
            if (a.equalsIgnoreCase("1"))
            {
                int coun = 0;
                builder pc1 = new gaming_pc();
                pc1.add_base_components();
                System.out.println("These base components are added to your pc for 70000 taka:");
                System.out.println("1.CPU");
                System.out.println("2.MOTHERBOARD");
                System.out.println("3.1 TB HDD");
                while (true)
                {
                    if (coun == 0) {
                        System.out.println("You have to add at least one component by pressing 1-5 before closing the order");
                    } else {
                        System.out.println("Press 1-5 according to which part you want to add to your pc and Press E to close the order");
                    }
                    System.out.println("1.AMD Ryzen Processor:28000 taka");
                    System.out.println("2.8 GB DDR4 RAM-2666 MHZ:2620 taka");
                    System.out.println("3.8 GB DDR4 RAM-3200 MHZ:2950 taka");
                    System.out.println("4.2 GB graphics card:6500 taka");
                    System.out.println("5.4 GB graphics card:7600 taka");

                    String tmp2 = input.nextLine();
                    if (tmp2.equals("1")) {
                        coun++;
                        pc1.add_processor();
                    } else if (tmp2.equals("2")) {
                        coun++;
                        pc1.add_8GB_DDR4_RAM_2666MHZ();
                    } else if (tmp2.equals("3")) {
                        coun++;
                        pc1.add_8GB_DDR4_RAM_3200MHZ();
                    } else if (tmp2.equals("4")) {
                        coun++;
                        pc1.add_2GB_graphics_card();
                    } else if (tmp2.equals("5")) {
                        coun++;
                        pc1.add_4GB_graphics_card();
                    } else if (coun > 0 && tmp2.equalsIgnoreCase("E")) {
                        System.out.println("You order a gaming pc");
                        product pro = pc1.get_pc();
                        pro.print();
                        break;
                    }
                    else
                    {
                        System.out.println("Error! Please follow the instruction");
                    }
                }
            }
            else if (a.equalsIgnoreCase("2"))
            {
                int coun = 0;
                builder pc2 = new regular_pc1();
                pc2.add_base_components();
                System.out.println("These base components are added to your pc for 70000 taka:");
                System.out.println("1.CPU");
                System.out.println("2.MOTHERBOARD");
                System.out.println("3.1 TB HDD");
                while (true) {
                    if (coun == 0) {
                        System.out.println("You have to add at least one component by pressing 1-5 before closing the order");
                    } else {
                        System.out.println("Press 1-6 according to which part you want to add to your pc and Press E to close the order");
                    }
                    System.out.println("1.Core i5 Processor:20000 taka");
                    System.out.println("2.CPU Cooler:36000 taka");
                    System.out.println("3.8 GB DDR4 RAM-2666 MHZ:2620 taka");
                    System.out.println("4.8 GB DDR4 RAM-3200 MHZ:2950 taka");
                    System.out.println("5.2 GB graphics card:6500 taka");
                    System.out.println("6.4 GB graphics card:7600 taka");
                    String tmp2 = input.nextLine();
                    if (tmp2.equals("1")) {
                        coun++;
                        pc2.add_processor();
                    } else if (tmp2.equals("2")) {
                        coun++;
                        pc2.add_cooler();
                    } else if (tmp2.equals("3")) {
                        coun++;
                        pc2.add_8GB_DDR4_RAM_2666MHZ();
                    } else if (tmp2.equals("4")) {
                        coun++;
                        pc2.add_8GB_DDR4_RAM_3200MHZ();
                    } else if (tmp2.equals("5")) {
                        coun++;
                        pc2.add_2GB_graphics_card();
                    } else if (tmp2.equals("6")) {
                        coun++;
                        pc2.add_4GB_graphics_card();
                    } else if (coun > 0 && tmp2.equalsIgnoreCase("E")) {
                        System.out.println("You order a regular pc with core i5");
                        product pro = pc2.get_pc();
                        pro.print();
                        break;
                    }
                    else
                    {
                        System.out.println("Error! Please follow the instruction");
                    }
                }
            }
            else if (a.equalsIgnoreCase("3"))
            {
                int coun = 0;
                builder pc3 = new regular_pc2();
                pc3.add_base_components();
                System.out.println("These base components are added to your pc for 70000 taka:");
                System.out.println("1.CPU");
                System.out.println("2.MOTHERBOARD");
                System.out.println("3.1 TB HDD");
                while (true) {
                    if (coun == 0) {
                        System.out.println("You have to add at least one component by pressing 1-5 before closing the order");
                    } else {
                        System.out.println("Press 1-6 according to which part you want to add to your pc and Press E to close the order");
                    }
                    System.out.println("1.Core i7 Processor:37000 taka");
                    System.out.println("2.Liquid Cooler:17000 taka");
                    System.out.println("3.8 GB DDR4 RAM-2666 MHZ:2620 taka");
                    System.out.println("4.8 GB DDR4 RAM-3200 MHZ:2950 taka");
                    System.out.println("5.2 GB graphics card:6500 taka");
                    System.out.println("6.4 GB graphics card:7600 taka");
                    String tmp2 = input.nextLine();
                    if (tmp2.equals("1")) {
                        coun++;
                        pc3.add_processor();
                    } else if (tmp2.equals("2")) {
                        coun++;
                        pc3.add_cooler();
                    } else if (tmp2.equals("3")) {
                        coun++;
                        pc3.add_8GB_DDR4_RAM_2666MHZ();
                    } else if (tmp2.equals("4")) {
                        coun++;
                        pc3.add_8GB_DDR4_RAM_3200MHZ();
                    } else if (tmp2.equals("5")) {
                        coun++;
                        pc3.add_2GB_graphics_card();
                    } else if (tmp2.equals("6")) {
                        coun++;
                        pc3.add_4GB_graphics_card();
                    } else if (coun > 0 && tmp2.equalsIgnoreCase("E")) {
                        System.out.println("You order a regular pc with core i7");
                        product pro = pc3.get_pc();
                        pro.print();
                        break;
                    }
                    else
                    {
                        System.out.println("Error! Please follow the instruction");
                    }
                }
            }
            else if (a.equalsIgnoreCase("4"))
            {
                int coun = 0;
                builder pc4 = new regular_pc3();
                pc4.add_base_components();
                System.out.println("These base components are added to your pc for 70000 taka:");
                System.out.println("1.CPU");
                System.out.println("2.MOTHERBOARD");
                System.out.println("3.1 TB HDD");
                while (true) {
                    if (coun == 0) {
                        System.out.println("You have to add at least one component by pressing 1-5 before closing the order");
                    } else {
                        System.out.println("Press 1-6 according to which part you want to add to your pc and Press E to close the order");
                    }
                    System.out.println("1.Core i9 Processor:65000 taka");
                    System.out.println("2.DVD Drive:6000 taka");
                    System.out.println("3.8 GB DDR4 RAM-2666 MHZ:2620 taka");
                    System.out.println("4.8 GB DDR4 RAM-3200 MHZ:2950 taka");
                    System.out.println("5.2 GB graphics card:6500 taka");
                    System.out.println("6.4 GB graphics card:7600 taka");
                    String tmp2 = input.nextLine();
                    if (tmp2.equals("1")) {
                        coun++;
                        pc4.add_processor();
                    } else if (tmp2.equals("2")) {
                        coun++;
                        pc4.add_dvd_drive();
                    } else if (tmp2.equals("3")) {
                        coun++;
                        pc4.add_8GB_DDR4_RAM_2666MHZ();
                    } else if (tmp2.equals("4")) {
                        coun++;
                        pc4.add_8GB_DDR4_RAM_3200MHZ();
                    } else if (tmp2.equals("5")) {
                        coun++;
                        pc4.add_2GB_graphics_card();
                    } else if (tmp2.equals("6")) {
                        coun++;
                        pc4.add_4GB_graphics_card();
                    } else if (coun > 0 && tmp2.equalsIgnoreCase("E")) {
                        System.out.println("You order a regular pc with core i9");
                        product pro = pc4.get_pc();
                        pro.print();
                        break;
                    }
                    else
                    {
                        System.out.println("Error! Please follow the instruction");
                    }

                }
            }

        }
    }
}
