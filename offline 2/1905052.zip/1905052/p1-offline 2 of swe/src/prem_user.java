import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;
public class prem_user
{
    public static void main(String[] args) throws IOException
    {
        System.out.println("Client started..");
        Socket socket = new Socket("127.0.0.1", 22222);
        System.out.println("Client Connected..");

        ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());

            Scanner sc = new Scanner(System.in);
        System.out.println("Are you a regular user or premium user?");
        System.out.println("If you are a regular user then type regular user");
        System.out.println("Or if you are a premium user then type premium user");
            String message = sc.nextLine();



            //sent to server...
            oos.writeObject(message);

            try {
                while(true) {
                    //receive from server..
                    Object fromServer = ois.readObject();
                    int prev=(int) fromServer;
                    fromServer=ois.readObject();
                    int curr=(int) fromServer;
                    if(prev==0&&curr==1)
                    {
                        System.out.println("The server of ABC company is previously on operational state");
                        System.out.println("The server of ABC company is currently on partially down state");
                        System.out.println("Select a option by typing 1 or 2");
                        System.out.println("1.Do you want to use service from two servers");
                        System.out.println("2.Do you want to use service from one server");
                        int tmp1=sc.nextInt();
                        if(tmp1==1)
                        {
                            System.out.println("Thanks for choosing 1");
                            oos.writeObject(tmp1);

                        }
                        else if(tmp1==2)
                        {
                            System.out.println("Thanks for choosing 2");
                            oos.writeObject(tmp1);

                        }
                    }
                    else if(prev==0&&curr==2)
                    {
                        System.out.println("The server of ABC company is previously on operational state");
                        System.out.println("The server of ABC company is currently on fully down state");
                        System.out.println("The service is now provided by our partner DEF company");
                        oos.writeObject("yes");
                    }
                    else if(prev==1&&curr==0)
                    {
                        System.out.println("The server of ABC company is previously on partially down state");
                        System.out.println("The server of ABC company is currently on operational state");
                    }
                    else if(prev==1&&curr==2)
                    {
                        System.out.println("The server of ABC company is previously on partially down state");
                        System.out.println("The server of ABC company is currently on fully down state");
                        System.out.println("We shift all services to the server of DEF company");
                    }
                    else if(prev==2&&curr==0)
                    {
                        System.out.println("The server of ABC company is previously on fully down state");
                        System.out.println("The server of ABC company is currently on operational state");
                    }
                    else if(prev==2&&curr==1)
                    {
                        System.out.println("The server of ABC company is previously on fully down state");
                        System.out.println("The server of ABC company is currently on partially down state");
                    }

                }

            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }


        socket.close();

    }
}
