public interface Spaceship
{
    void work();
}
