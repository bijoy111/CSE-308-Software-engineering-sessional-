public abstract class user
{
    public abstract void sendMsg(String msg);
    public abstract void showMsg(String msg);
    public abstract void setId(int id);
    public abstract int getId();

}
