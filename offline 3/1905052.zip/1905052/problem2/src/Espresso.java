public class Espresso extends Coffee_decorator
{
    public Espresso(Coffee coffee)
    {
        super(coffee);
    }
    public int get_cost()
    {
        return coffee.get_cost()+40;
    }
    public String get_ingredients()
    {
        return coffee.get_ingredients()+"dairy_cream";
    }
}
