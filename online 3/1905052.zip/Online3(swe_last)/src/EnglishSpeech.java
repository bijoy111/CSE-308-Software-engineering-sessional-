public class EnglishSpeech implements Speech
{
    private String speech;

    public EnglishSpeech(String speech)
    {
        this.speech = speech;
    }

    @Override
    public String generateScript()
    {
        return speech.substring(1, speech.length() - 1);
    }
}