public abstract class Coffee_decorator extends Coffee
{
    protected Coffee coffee;

    public Coffee_decorator(Coffee coffee)
    {
        this.coffee = coffee;
    }

    @Override
    public abstract int get_cost();

    @Override
    public abstract String get_ingredients();
}
