public interface car
{
    void set_color(String tmp);
    String get_color();
    void set_manufacturingCountry(String tmp);
    String get_manufacturingCountry();
    void set_engine(String tmp);
    String get_engine();
    void set_driveTrain(String tmp);
    String get_driveTrain();
    void print();
}
