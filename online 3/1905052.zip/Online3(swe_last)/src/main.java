import java.util.Scanner;

public class main
{
    public static void main(String[] args)
    {
        while(true)
        {
            Scanner input = new Scanner(System.in);
            String str = input.nextLine();
            if(str.substring(1,1)=="H"||str.substring(1,1)=="T")
            {
                Speech englishSpeech = new EnglishSpeech(str);
                System.out.println(englishSpeech.generateScript());
            }
            else
            {
                Speech banglaSpeech = new BanglaSpeechAdapter(str);
                System.out.println(banglaSpeech.generateScript());
            }
        }

    }
}
