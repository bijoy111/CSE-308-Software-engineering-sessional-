public class equal_price implements state
{
    public void doAction(controller con)
    {
        con.set_state(this);
    }
    public String toString()
    {
        return "your given money is equal to the price of product";
    }
}
