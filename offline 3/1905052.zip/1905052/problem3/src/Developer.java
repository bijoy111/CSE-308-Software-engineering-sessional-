public class Developer implements Personnel
{
    private String name;
    private String role = "Developer";
    private String project;
    public Developer(String name,String project)
    {
        this.name=name;
        this.project=project;
    }
    public String get_name()
    {
        return name;
    }
    @Override
    public void show_details()
    {
        System.out.println("developer_component.details():");
        System.out.println("Name: " +name);
        System.out.println("Role: "+role);
        System.out.println("Current Project: "+project);
    }
}
