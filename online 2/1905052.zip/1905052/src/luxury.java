public class luxury implements mediator
{
    public void showMsg(String msg)
    {

    }
}
