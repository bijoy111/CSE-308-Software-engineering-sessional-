public class factory
{
    public car get_car(String tmp)
    {
        if(tmp.equalsIgnoreCase("Asia"))
        {
            car obj=new toyota();
            obj.set_color("Red");
            obj.set_manufacturingCountry("Japan");
            obj.set_engine("Hydrogen Fuel Cell");
            obj.set_driveTrain("Rear wheel drive train");
            return obj;
        }
        else if(tmp.equalsIgnoreCase("Europe"))
        {
            car obj=new bmw();
            obj.set_color("Black");
            obj.set_manufacturingCountry("Germany");
            obj.set_engine("Electric engine");
            obj.set_driveTrain("Rear wheel drive train");
            return obj;
        }
        else if(tmp.equalsIgnoreCase("United State"))
        {
            car obj=new tesla();
            obj.set_color("White");
            obj.set_manufacturingCountry("US");
            obj.set_engine("Electric engine");
            obj.set_driveTrain("All wheels for drive train");
            return obj;
        }
        return null;
    }
}
