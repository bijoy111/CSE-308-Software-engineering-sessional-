public class regular_pc3 implements builder
{
    private product prod=new product();
    @Override
    public void add_base_components()
    {
        prod.add("CPU");
        prod.add("MOTHERBOARD");
        prod.add("1 TB HDD");
        prod.set_basePrice(70000);
    }
    @Override
    public void add_processor()
    {
        prod.add("Core i9 processor");
        prod.increase_addPrice(65000);
    }
    @Override
    public void add_cooler()
    {

    }
    @Override
    public void add_dvd_drive()
    {
        prod.add("DVD Drive");
        prod.increase_addPrice(6000);
    }
    @Override
    public void add_8GB_DDR4_RAM_2666MHZ()
    {
        prod.add("8 GB DDR4 RAM-2666MHZ");
        prod.increase_addPrice(2620);
    }
    @Override
    public void add_8GB_DDR4_RAM_3200MHZ()
    {
        prod.add("8 GB DDR4 RAM-3200MHZ");
        prod.increase_addPrice(2950);
    }
    @Override
    public void add_2GB_graphics_card()
    {
        prod.add("2 GB graphics card");
        prod.increase_addPrice(6500);
    }
    @Override
    public void add_4GB_graphics_card()
    {
        prod.add("4 GB graphics card");
        prod.increase_addPrice(7600);
    }
    @Override
    public product get_pc()
    {
        return prod;
    }
}
