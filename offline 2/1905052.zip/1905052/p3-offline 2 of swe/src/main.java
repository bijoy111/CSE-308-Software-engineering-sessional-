import java.util.*;

public class main
{
    public static void main(String[] args)
    {
        Scanner input= new Scanner(System.in);
        int tot_product=5;
        int price_per_product=10;
        while(tot_product>0) {
            System.out.println("There is " + tot_product + " product in the vending machine");
            System.out.println("The price of each product is " + price_per_product + " taka");
            System.out.println("Give your money in the vending machine:");
            int p = input.nextInt();
            controller con = new controller();
            if (p < price_per_product) {
                less_price less = new less_price();
                less.doAction(con);
                System.out.println(con.get_state().toString());
                System.out.println("Take your money");
            } else if (p == price_per_product) {
                equal_price equal = new equal_price();
                equal.doAction(con);
                System.out.println(con.get_state().toString());
                System.out.println("Take your product");
                tot_product--;
            } else if (p > price_per_product) {
                more_price more = new more_price();
                more.doAction(con);
                System.out.println(con.get_state().toString());
                System.out.println("Take your product");
                System.out.println("Take your extra money:"+(p-price_per_product)+" taka");
                tot_product--;
            }
        }
        System.out.println("There is no product in the vending machine");
    }
}
