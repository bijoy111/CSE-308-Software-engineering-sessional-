public class less_price implements state
{
    public void doAction(controller con)
    {
        con.set_state(this);
    }
    public String toString()
    {
        return "your given money is not enough to buy the product";
    }
}
