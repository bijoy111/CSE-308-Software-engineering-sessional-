import java.util.*;

public class product
{
    private LinkedList<String>parts;
    private int base_price;
    private int add_price;
    public product()
    {
        parts=new LinkedList<String>();
        base_price=0;
        add_price=0;
    }
    public void add(String part)
    {
        parts.addLast(part);
    }
    public void print()
    {
        System.out.println("The list of components of your pc is:");
        for(int i=0;i<parts.size();i++)
        {
            System.out.println(parts.get(i));
        }
        System.out.println("The base price of this pc is:"+base_price);
        System.out.println("The total price of the added components are:"+add_price);
        System.out.println("So the total price of your pc is:"+(base_price+add_price));
    }
    public void set_basePrice(int tm)
    {
        base_price=tm;
    }
    public int get_basePrice()
    {
        return base_price;
    }
    public void increase_addPrice(int tm)
    {
        add_price+=tm;
    }
    public int get_addPrice()
    {
        return add_price;
    }
}
