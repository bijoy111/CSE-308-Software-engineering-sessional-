public class student3 extends user
{
    private int id;
    private mediator med;
    public student3(mediator m)
    {
        med=m;
    }
    public void setId(int id)
    {
        this.id=id;
    }
    public int getId()
    {
        return id;
    }
    public void sendMsg(String msg)
    {
        med.showMsg(this,msg);
    }
    public void showMsg(String msg)
    {
        System.out.println(msg+id);
    }
}
