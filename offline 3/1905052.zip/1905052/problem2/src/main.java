import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class main
{
    public static void main(String[] args)
    {
        Coffee black=new Black_coffee();
        Coffee milk=new Milk_coffee();
        Scanner input= new Scanner(System.in);
        List<String> list1=new ArrayList<String>();
        System.out.println("There are 4 types of coffee available in our coffee shop : Americano,espresso,cappuccino and mocha");
        System.out.println("Which one you want to order");
        String coff=input.nextLine();
        list1.add(coff);
        while(true)
        {
            System.out.println("Do you want order some other type of coffee?");
            coff=input.nextLine();
            if(coff.equalsIgnoreCase("no"))
            {
                break;
            }
            list1.add(coff);
        }
        for(String t:list1)
        {
            if(t.equalsIgnoreCase("americano"))
            {
                Coffee americano=new Americano(black);
                System.out.println("The price of americano is: "+ americano.get_cost());
                System.out.println("The ingredients used in americano are: "+americano.get_ingredients());
            }
            else if(t.equalsIgnoreCase("espresso"))
            {
                Coffee espresso=new Espresso(black);
                System.out.println("The price of espresso is: "+ espresso.get_cost());
                System.out.println("The ingredients used in espresso are: "+espresso.get_ingredients());
            }
            else if(t.equalsIgnoreCase("cappuccino"))
            {
                Coffee cappuccino=new Cappuccino(milk);
                System.out.println("The price of cappuccino is: "+ cappuccino.get_cost());
                System.out.println("The ingredients used in cappuccino are: "+cappuccino.get_ingredients());
            }
            else if(t.equalsIgnoreCase("mocha"))
            {
                Coffee mocha=new Mocha(milk);
                System.out.println("The price of mocha is: "+ mocha.get_cost());
                System.out.println("The ingredients used in mocha are: "+mocha.get_ingredients());
            }
        }


    }
}
