public abstract class Coffee
{
    abstract int get_cost();
    abstract String get_ingredients();
}
