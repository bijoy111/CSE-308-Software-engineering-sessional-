public interface Personnel
{
    void show_details();
}
