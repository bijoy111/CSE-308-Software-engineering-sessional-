public class Cappuccino extends Coffee_decorator
{
    public Cappuccino(Coffee coffee)
    {
        super(coffee);
    }
    public int get_cost()
    {
        return coffee.get_cost()+50;
    }
    public String get_ingredients()
    {
        return coffee.get_ingredients()+"cinnamon_powder";
    }
}
