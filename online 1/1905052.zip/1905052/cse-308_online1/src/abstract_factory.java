public abstract class abstract_factory
{
    abstract Engine getEngine(String tmp);
    abstract Wing getWing(String tmp);
}
