public class Imposter
{
    private adapter adap;
    public Imposter(adapter adap)
    {
        this.adap=adap;
    }
    void damage()
    {
        adap.kill();
    }
}
