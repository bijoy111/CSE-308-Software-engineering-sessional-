import java.util.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
public class server
{
    public static void main(String[] args) throws IOException
    {
        ServerSocket serverSocket = new ServerSocket(22222);
        System.out.println("Server Started..");



        while (true)
        {
            Socket socket = serverSocket.accept();
            System.out.println("Client connected..");

            // new Server Thread Start.....
            new ServerThread(socket);


        }
    }
}
class ServerThread implements Runnable
{

    Socket clientSocket;
    Thread t;

    ServerThread(Socket clientSocket){
        this.clientSocket = clientSocket;
        t= new Thread(this);
        t.start();
    }


    @Override
    public void run() {

        try {
            ObjectInputStream ois = new ObjectInputStream(clientSocket.getInputStream());
            ObjectOutputStream oos = new ObjectOutputStream(clientSocket.getOutputStream());


                Scanner input= new Scanner(System.in);
                //read from client...
                Object cMsg = ois.readObject();


                String serverMsg = (String) cMsg;
                //System.out.println(serverMsg);

                subject sub=new subject();

            int s;
            if(serverMsg.equalsIgnoreCase("regular user"))
            {
                System.out.println(serverMsg+" uses the server");
                new reg_observer(sub);
                while(true)
                {
                    /*System.out.println("0. Operational state");
                    System.out.println("1. Partially down state");
                    System.out.println("2. Fully down state");
                    System.out.println("Type the index according to the state you want to change for the regular user");*/
                    s = input.nextInt();
                    int prev=sub.getState();
                    sub.setState(s);
                    int curr=sub.getState();
                    //send to client..
                    oos.writeObject(prev);
                    oos.writeObject(curr);
                    if(prev==0&&curr==1)
                    {
                        Object ob = ois.readObject();
                        int tm=(int) ob;
                        if(tm==1)
                        {
                            System.out.println("Regular user want to continue using the limited functionality");
                        }
                        else if(tm==2)
                        {
                            System.out.println("Regular user want to pay $20 per hour to enjoy the full functionality taking service from DEF company");
                        }

                    }
                    if(prev==0&&curr==2)
                    {
                        Object ob = ois.readObject();
                        String tm=(String) ob;
                        if(tm.equalsIgnoreCase("yes"))
                        {
                            System.out.println("Regular user want to pay $20 per hour to take service from DEF company");
                        }
                        else if(tm.equalsIgnoreCase("no"))
                        {
                            System.out.println("Regular user does not want to pay $20 per hour to take service from DEF company");
                        }

                    }
                }
            }
            else if(serverMsg.equalsIgnoreCase("premium user"))
            {
                System.out.println(serverMsg+" uses the server");
                new prem_observer(sub);
                while(true)
                {
                    System.out.println("0. Operational state");
                    System.out.println("1. Partially down state");
                    System.out.println("2. Fully down state");
                    System.out.println("Type the index twice according to the state you want to change for the premium user and regular user");
                    s = input.nextInt();
                    int prev=sub.getState();
                    sub.setState(s);
                    int curr=sub.getState();
                    //send to client..
                    oos.writeObject(prev);
                    oos.writeObject(curr);
                    if(prev==0&&curr==1)
                    {
                        Object ob = ois.readObject();
                        int tm=(int) ob;
                        if(tm==1)
                        {
                            System.out.println("Premium user want to use service from two servers");
                        }
                        else if(tm==2)
                        {
                            System.out.println("Premium user want to use service from one server");
                        }

                    }
                    if(prev==0&&curr==2)
                    {
                        Object ob = ois.readObject();
                        String str=(String)ob;
                        if(ob=="yes")
                        {
                            str+="no";
                        }
                        else
                        {
                            str+="yes";
                        }
                    }
                }
            }





        } catch (ClassNotFoundException | IOException e) {
            e.printStackTrace();
        }

        try {
            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
