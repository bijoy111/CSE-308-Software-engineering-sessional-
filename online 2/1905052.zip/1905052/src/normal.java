public class normal implements mediator
{
    public void showMsg(String msg)
    {
        System.out.println(msg);
    }
}
