import java.util.*;
public class concretemediator implements mediator
{
    List<Integer> list=new ArrayList<Integer>();
    public concretemediator()
    {
        list.add(new java.util.Random().nextInt(100));
        list.add(new java.util.Random().nextInt(100));
        list.add(new java.util.Random().nextInt(100));
        list.add(new java.util.Random().nextInt(100));
        list.add(new java.util.Random().nextInt(100));
    }
    public void showMarks()
    {
        for(int i=0;i<list.size();i++)
        {
            System.out.println("Student id: "+(i+1)+" Marks: "+list.get(i));
        }
    }
    public void showMsg(user u,String msg)
    {
        System.out.println(msg+u.getId());
        examiner ex=new examiner(this);
        int tmp=ex.checkScripts();
        if(tmp==-1)
        {
            System.out.println("Your mark is correct");
        }
        else
        {
            System.out.println("Sorry, there is a mistake in counting mark");
            System.out.println("Student Id: "+u.getId()+" Previous Marks: "+list.get(u.getId()-1)+" Current Marks: "+(tmp));
        }
    }
}
