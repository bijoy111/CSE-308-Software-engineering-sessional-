public class Mocha extends Coffee_decorator
{
    public Mocha(Coffee coffee)
    {
        super(coffee);
    }
    public int get_cost()
    {
        return coffee.get_cost()+60;
    }
    public String get_ingredients()
    {
        return coffee.get_ingredients()+"chocolate_sauce";
    }
}
