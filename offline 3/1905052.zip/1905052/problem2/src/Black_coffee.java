public class Black_coffee extends Coffee
{
    int cost=130;//price of mugs,grinded coffee beans are 100,30 taka
    public int get_cost()
    {
        return cost;
    }
    public String get_ingredients()
    {
        return "regular_black_coffee    ";
    }
}
