public class Wing
{
    private String win;
    public void set_wing(String tmp)
    {
        win=tmp;
    }
    public String get_wing()
    {
        return win;
    }
    public void print()
    {
        System.out.println(win);
    }
}
