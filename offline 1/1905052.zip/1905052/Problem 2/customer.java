import java.util.*;

public class customer
{
    public static void main(String[] args)
    {
        System.out.println("Design pattern is Factory Method");
        Scanner input= new Scanner(System.in);
        System.out.println("What is your location: Asia or Europe or United States");
        System.out.println("Type your location like the mentioned above");
        String tmp1=input.nextLine();
        while(true)
        {
            if(tmp1.equalsIgnoreCase("Asia")||tmp1.equalsIgnoreCase("Europe")||tmp1.equalsIgnoreCase("United States"))
            {
                break;
            }
            else
            {
                System.out.println("Error!");
                System.out.println("Please type your location out of Asia,Europe,United States");
                tmp1=input.nextLine();
            }
        }
        factory temp=new factory();
        car obj=temp.get_car(tmp1);
        obj.print();
    }
}
