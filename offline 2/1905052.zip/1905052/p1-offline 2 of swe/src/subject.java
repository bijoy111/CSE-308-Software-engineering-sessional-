import java.util.ArrayList;
import java.util.List;
public class subject
{
    private List<observer> observers=new ArrayList<observer>();//list of observer
    private int state=0;//operational state
    public int getState()
    {
        return state;
    }
    public void setState(int s)
    {
        state=s;
        notifyAllobservers(state);
    }
    public void attach(observer ob)
    {
        observers.add(ob);
    }
    public void notifyAllobservers(int s)
    {
        for(observer ob:observers)
        {
            ob.update(s);
        }
    }
}
