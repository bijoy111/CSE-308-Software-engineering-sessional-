import java.util.*;

public class customer
{
    public static void main(String[] args)
    {
        System.out.println("Design pattern is Abstract Factory Method");
        Scanner input= new Scanner(System.in);
        System.out.println("What is your preferred company: Boeing or AirBus or Safram");
        System.out.println("Type your preferred company like the mentioned above");
        String tmp1=input.nextLine();
        while(true)
        {
            if(tmp1.equalsIgnoreCase("Boeing")||tmp1.equalsIgnoreCase("AirBus")||tmp1.equalsIgnoreCase("Safram"))
            {
                break;
            }
            else
            {
                System.out.println("Error!");
                System.out.println("Please type your preferred company out of Boeing or AirBus or Safram");
                tmp1=input.nextLine();
            }
        }
        abstract_factory absf=factoryProducer.getFactory("engine");
        Engine eng1=absf.getEngine(tmp1);
        eng1.print();
        abstract_factory absf1=factoryProducer.getFactory("wing");
        Wing win1=absf1.getWing(tmp1);
        win1.print();
        // temp=new factory();
        //car obj=temp.get_car(tmp1);
        //obj.print();
    }
}
