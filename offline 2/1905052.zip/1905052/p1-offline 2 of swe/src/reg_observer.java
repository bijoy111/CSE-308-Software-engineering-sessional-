public class reg_observer extends observer
{
    private int prevstate;
    private int currstate=0;
    public reg_observer(subject sub)
    {
        this.sub=sub;
        this.sub.attach(this);
    }

    @Override
    public void update(int s)
    {
        prevstate=currstate;
        currstate=s;
    }
    public int get_prevState()
    {
        return prevstate;
    }
    public int get_currState()
    {
        return currstate;
    }
}
