public class factoryProducer
{
    public static abstract_factory getFactory(String choice)
    {
        if(choice.equalsIgnoreCase("engine"))
        {
            return new engine_factory();
        }
        else if(choice.equalsIgnoreCase("wing"))
        {
            return new wing_factory();
        }
        return null;
    }
}
