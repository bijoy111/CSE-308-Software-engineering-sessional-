public class Engine
{
    private String eng;
    public void set_engine(String tmp)
    {
        eng=tmp;
    }
    public String get_engine()
    {
        return eng;
    }
    public void print()
    {
        System.out.println(eng);
    }
}
