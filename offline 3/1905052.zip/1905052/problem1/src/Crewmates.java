public class Crewmates implements Spaceship
{
    @Override
    public void work()
    {
        //the word is done by crewmates here
        System.out.println("Studying the interstellar objects");
        System.out.println("Doing basic maintenance tasks of the spaceship");
    }
}
