import java.util.ArrayList;

public class Manager implements Personnel
{
    private String name;
    private String role = "Project Manager";
    private String project;
    private ArrayList<Developer> developers = new ArrayList<>();
    public Manager(String name, String project)
    {
        this.name=name;
        this.project=project;
    }

    public void addDeveloper(Developer developer)
    {
        developers.add(developer);
    }

    public void removeDeveloper(Developer developer)
    {
        developers.remove(developer);
    }

    public ArrayList<Developer> getDevelopers()
    {
        return developers;
    }
    public String get_name()
    {
        return name;
    }
    public String get_Projectname()
    {
        return project;
    }
    @Override
    public void show_details()
    {
        System.out.println("manager_component.details():");
        System.out.println("Name: " +name);
        System.out.println("Role: "+role);
        System.out.println("Current Project: "+project);
        System.out.println("Number of Supervisees: "+developers.size());
    }

}
