public class adapter implements Spaceship
{
    @Override
    public void work()
    {
        System.out.println("Studying the interstellar objects");
        System.out.println("Doing basic maintenance tasks of the spaceship");
    }
    public void kill()
    {
        System.out.println("Poisoning the crewmate");
        System.out.println("Damage the spaceship");
    }
}
