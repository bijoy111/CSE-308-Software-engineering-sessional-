public class engine_factory extends abstract_factory
{
    private Engine obj=new Engine();
    @Override
    public Engine getEngine(String tmp)
    {
        if(tmp==null)
        {
            return null;
        }
        else if(tmp.equalsIgnoreCase("Boeing"))
        {
            obj.set_engine("Boeing");
        }
        else if(tmp.equalsIgnoreCase("AirBus"))
        {
            obj.set_engine("AirBus");
        }
        else if(tmp.equalsIgnoreCase("Safram"))
        {
            obj.set_engine("Safram");
        }
        return null;
    }

    @Override
    Wing getWing(String tmp) {
        return null;
    }
}
