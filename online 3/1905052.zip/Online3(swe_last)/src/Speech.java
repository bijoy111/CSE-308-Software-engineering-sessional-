public interface Speech
{
    String generateScript();
}