public class main
{
    public static void main(String[] args)
    {
        Imposter imposter=new Imposter(new adapter());
        imposter.damage();
    }
}
