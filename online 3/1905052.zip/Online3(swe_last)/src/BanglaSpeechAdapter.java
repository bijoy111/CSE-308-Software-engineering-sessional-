public class BanglaSpeechAdapter implements Speech
{
    private EnglishSpeech englishSpeech;
    private String banglaSpeech;


    public BanglaSpeechAdapter(String banglaSpeech)
    {
        this.banglaSpeech = banglaSpeech;
    }

    @Override
    public String generateScript()
    {
        String str = null;
        if(banglaSpeech=="“Amra bhat khai.”")
        {
            str ="We eat rice.";
        }
        else if(banglaSpeech=="“Ami roti banai.”")
        {
            str = "We eat rice.";
        }
        englishSpeech = new EnglishSpeech(str);
        return this.englishSpeech.generateScript();
    }

}