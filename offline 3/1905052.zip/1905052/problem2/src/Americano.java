public class Americano extends Coffee_decorator
{
    public Americano(Coffee coffee)
    {
        super(coffee);
    }
    public int get_cost()
    {
        return coffee.get_cost()+30;
    }
    public String get_ingredients()
    {
        return coffee.get_ingredients()+"additional_grinded_coffee_beans";
    }
}
