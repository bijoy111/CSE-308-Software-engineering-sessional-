public interface mediator
{
    public void showMarks();
    public void showMsg(user u,String msg);
}
