public class Milk_coffee extends Coffee
{
    int cost=180;//price of mug,milk,grinded coffee beans are 100,50,30 taka
    public int get_cost()
    {
        return cost;
    }
    public String get_ingredients()
    {
        return "regular_milk_coffee     ";
    }
}
