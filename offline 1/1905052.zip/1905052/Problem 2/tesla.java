public class tesla implements car
{
    private String col;
    private String con;
    private String eng;
    private String tra;

    public void set_color(String tmp)
    {
        col=tmp;
    }
    @Override
    public String get_color()
    {
        return col;
    }
    @Override
    public void set_manufacturingCountry(String tmp)
    {
        con=tmp;
    }
    @Override
    public String get_manufacturingCountry()
    {
        return con;
    }
    @Override
    public void set_engine(String tmp)
    {
        eng=tmp;
    }
    @Override
    public String get_engine()
    {
        return eng;
    }
    @Override
    public void set_driveTrain(String tmp)
    {
        tra=tmp;
    }
    @Override
    public String get_driveTrain()
    {
        return tra;
    }
    @Override
    public void print()
    {
        System.out.println("The details of your car:");
        System.out.println("Color:"+col);
        System.out.println("Manufacturing country:"+con);
        System.out.println("Engine:"+eng);
        System.out.println("Drivetrain system:"+tra);
    }
}
