import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class main
{
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<Company> companies = new ArrayList<Company>();
        ArrayList<Manager> managers = new ArrayList<Manager>();
        ArrayList<Developer> developers = new ArrayList<Developer>();

        while(true)
        {
            System.out.println("Do you want to add or remove");
            String in = input.nextLine();
            if (in.equalsIgnoreCase("remove"))
            {
                System.out.println("Do you want to remove company or manager or developer");
                String tmp1 = input.nextLine();

                if (tmp1.equalsIgnoreCase("company"))
                {
                    System.out.println("Which company you want to remove");
                    System.out.println("The list of companies are:");
                    for (Company com : companies)
                    {
                        System.out.println(com.get_name());
                    }
                    String tmp2 = input.nextLine();//company name
                    for (Company com : companies)
                    {
                        if (com.get_name().equalsIgnoreCase(tmp2))
                        {
                            managers = com.getManagers();
                            for (Manager m : managers)
                            {
                                developers = m.getDevelopers();
                                for (Developer d : developers)
                                {
                                    m.removeDeveloper(d);
                                }
                                com.removeManager(m);
                            }
                            companies.remove(com);
                            break;
                        }
                    }
                }
                else if (tmp1.equalsIgnoreCase("manager"))
                {
                    System.out.println("Which company has this manager");
                    System.out.println("The list of company are:");
                    for (Company com : companies)
                    {
                        System.out.println(com.get_name());
                    }
                    String tmp2 = input.nextLine();//company name
                    for (Company com : companies)
                    {
                        if (com.get_name().equalsIgnoreCase(tmp2))
                        {
                            System.out.println("Which manager you want to remove");
                            managers=com.getManagers();
                            System.out.println("The list of managers are:");
                            for (Manager man : managers)
                            {
                                System.out.println(man.get_name());
                            }
                            String tmp3 = input.nextLine();//manager name
                            for (Manager man : managers)
                            {
                                if (man.get_name().equalsIgnoreCase(tmp3))
                                {
                                    developers = man.getDevelopers();
                                    for (Developer d : developers)
                                    {
                                        man.removeDeveloper(d);
                                    }
                                    com.removeManager(man);
                                    break;
                                }
                            }
                            break;
                        }
                    }
                }
                else if (tmp1.equalsIgnoreCase("developer"))
                {
                    System.out.println("Which company has this developer");
                    System.out.println("The list of company are:");
                    for (Company com : companies)
                    {
                        System.out.println(com.get_name());
                    }
                    String tmp2 = input.nextLine();//company name
                    for (Company com : companies)
                    {
                        if (com.get_name().equalsIgnoreCase(tmp2))
                        {
                            System.out.println("Which manager has this developer");
                            System.out.println("The list of managers are:");
                            managers = com.getManagers();
                            for (Manager m : managers)
                            {
                                System.out.println(m.get_name());
                            }
                            String tmp3 = input.nextLine();//manager name
                            for (Manager m : managers)
                            {
                                if (m.get_name().equalsIgnoreCase(tmp3))
                                {
                                    System.out.println("Which developer you want to remove");
                                    developers = m.getDevelopers();
                                    System.out.println("The list of developers are:");
                                    for (Developer d : developers)
                                    {
                                        System.out.println(d.get_name());
                                    }
                                    String tmp4 = input.nextLine();//developer name
                                    for (Developer d : developers)
                                    {
                                        if (d.get_name().equalsIgnoreCase(tmp4)) {
                                            m.removeDeveloper(d);
                                        }
                                    }
                                    break;
                                }
                            }
                            break;
                        }
                    }
                }
            }
            else if (in.equalsIgnoreCase("add"))
            {
                System.out.println("Do you want to make company or manager or developer");
                String tmp1 = input.nextLine();
                if (tmp1.equalsIgnoreCase("company")) {
                    System.out.println("Give the company name");
                    String tmp2 = input.nextLine();//company name
                    Company company = new Company(tmp2);
                    companies.add(company);
                } else if (tmp1.equalsIgnoreCase("manager")) {
                    if (companies.size() == 0) {
                        System.out.println("Error! There is no company to add the manager");
                    } else {
                        System.out.println("Which company you want to select for this manager");
                        System.out.println("The list of company are:");
                        for (Company com : companies) {
                            System.out.println(com.get_name());
                        }
                        String tmp2 = input.nextLine();//company name
                        System.out.println("Give the manager name");
                        String tmp3 = input.nextLine();//manager name
                        System.out.println("Give the project name");
                        String tmp4 = input.nextLine();//project name
                        for (Company com : companies) {
                            if (com.get_name().equalsIgnoreCase(tmp2)) {
                                com.addManager(new Manager(tmp3, tmp4));
                                break;
                            }
                        }
                    }
                } else if (tmp1.equalsIgnoreCase("developer")) {
                    if (companies.size() == 0) {
                        System.out.println("Error! There is no company");
                    } else {
                        System.out.println("Which company you want to select for this developer");
                        System.out.println("The list of company are:");
                        for (Company com : companies) {
                            System.out.println(com.get_name());
                        }
                        String tmp2 = input.nextLine();//company name
                        for (Company com : companies) {
                            if (com.get_name().equalsIgnoreCase(tmp2)) {
                                managers = com.getManagers();
                                break;
                            }
                        }
                        if (managers.size() == 0) {
                            System.out.println("Error! There is no manager");
                        } else {
                            System.out.println("Which manager you want to select for this developer");
                            System.out.println("The list of manager are:");
                            for (Manager man : managers) {
                                System.out.println(man.get_name());
                            }
                            String tmp3 = input.nextLine();//manager name
                            System.out.println("Give the developer name");
                            String tmp4 = input.nextLine();//developer name
                            for (Manager m : managers) {
                                if (m.get_name().equalsIgnoreCase(tmp3)) {
                                    m.addDeveloper(new Developer(tmp4, tmp3));
                                    break;
                                }
                            }

                        }
                    }
                }
                System.out.println("company_composite.hierarchy():");
                for (Company com : companies) {
                    com.hierarchy();
                }
                for(Company com:companies)
                {
                    for(Manager m:com.getManagers())
                    {
                        m.show_details();
                        for(Developer d:m.getDevelopers())
                        {
                            d.show_details();
                        }
                    }
                }
            }
        }
    }

}