import java.util.*;
public class examiner extends user
{
    private int id;
    private mediator med;
    public examiner(mediator m)
    {
        med=m;
    }
    public void setId(int id)
    {
        this.id=id;
    }
    public int getId()
    {
        return id;
    }
    public void sendMsg(String msg)
    {
        med.showMsg(this,msg);
    }
    public void showMsg(String msg)
    {
        System.out.println(msg+id);
    }
    public int checkScripts()
    {

        if(new java.util.Random().nextInt(2)==0)
        {
            return new java.util.Random().nextInt(100);
        }
        else
        {
            return -1;
        }
    }
}
