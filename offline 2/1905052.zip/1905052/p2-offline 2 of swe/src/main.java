import java.util.*;
public class main
{
    public static void main(String[] args)
    {
        Scanner input= new Scanner(System.in);
        mediator conmed=new concretemediator();
        conmed.showMarks();
        examiner e=new examiner(conmed);
        student1 s1=new student1(conmed);
        student2 s2=new student2(conmed);
        student3 s3=new student3(conmed);
        student4 s4=new student4(conmed);
        student5 s5=new student5(conmed);
        while(true) {
            System.out.println("Who want to re-examine the scripts");
            int id = input.nextInt();
            if (id == 1) {
                s1.setId(id);
                s1.showMsg("re-examine request sent from student id ");
                s1.sendMsg("re-examine request got from student id ");
            } else if (id == 2) {
                s2.setId(id);
                s2.showMsg("re-examine request sent from student id ");
                s2.sendMsg("re-examine request got from student id ");
            } else if (id == 3) {
                s3.setId(id);
                s3.showMsg("re-examine request sent from student id ");
                s3.sendMsg("re-examine request got from student id ");
            } else if (id == 4) {
                s4.setId(id);
                s4.showMsg("re-examine request sent from student id ");
                s4.sendMsg("re-examine request got from student id ");
            } else if (id == 5) {
                s5.setId(id);
                s5.showMsg("re-examine request sent from student id ");
                s5.sendMsg("re-examine request got from student id ");
            }
        }
    }
}
