import java.util.Scanner;
public class customer
{
    private mediator med;
    public customer(mediator m)
    {
        med=m;
    }

    public void sendMsg(String msg)
    {
        med.showMsg(msg);
    }
    public void showMsg(String msg)
    {
        System.out.println(msg);
    }
    public void update(int p)
    {

        System.out.println("Do you want to continue with the new price");
        System.out.println("If yes then press 1 or press 2");
        Scanner input= new Scanner(System.in);
        int tmp=input.nextInt();
        if(tmp==1)
        {
            sendMsg("I want to continue");
        }
        else if(tmp==2)
        {
            sendMsg("I do not want to continue");
        }
    }
}
