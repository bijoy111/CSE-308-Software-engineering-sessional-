import java.util.Scanner;

public class main
{
    public static void main(String[] args)
    {
        while(true) {
            Scanner input = new Scanner(System.in);
            System.out.println("which type of car you want to rent");
            System.out.println("1.normal");
            System.out.println("2.luxury");
            int p = input.nextInt();
            if (p == 1) {
                //System.out.println("Your rent will be 500 taka per day");
                mediator med1 = new normal();
                customer cus = new customer(med1);
                cus.showMsg("Your rent will be 500 taka per day");
                System.out.println("If you want to change the price type 1 or type 2");
                int type = input.nextInt();
                if (type == 1) {
                    System.out.println("How much taka you want per day");
                    int taka = input.nextInt();
                    cus.showMsg("Your rent from now will be " + taka + "taka per day");
                }
            } else if (p == 2) {
                //System.out.println("Your rent will be 700 taka per day");
                mediator med2 = new luxury();
                customer cus = new customer(med2);
                cus.showMsg("Your rent will be 700 taka per day");
                System.out.println("If you want to change the price type 1 or type 2");
                int type = input.nextInt();
                if (type == 1) {
                    System.out.println("How much taka you want per day");
                    int taka = input.nextInt();
                    cus.showMsg("Your rent from now will  be" + taka + "taka per day");
                }
            }
            System.out.println("Thanks for the rent from our company");
        }
    }
}
