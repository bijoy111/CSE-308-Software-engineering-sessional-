public class more_price implements state
{
    public void doAction(controller con)
    {
        con.set_state(this);
    }
    public String toString()
    {
        return "your given money is much than the price of product";
    }
}
